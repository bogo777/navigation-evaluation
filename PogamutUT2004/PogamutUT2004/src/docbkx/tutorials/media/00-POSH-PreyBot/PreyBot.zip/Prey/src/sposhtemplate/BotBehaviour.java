package sposhtemplate;

import cz.cuni.amis.pogamut.base.utils.math.DistanceUtils;
import cz.cuni.amis.pogamut.base3d.worldview.object.Location;
import cz.cuni.amis.pogamut.sposh.SPOSHAction;
import cz.cuni.amis.pogamut.sposh.SPOSHSense;
import cz.cuni.amis.pogamut.ut2004.bot.impl.UT2004Bot;
import cz.cuni.amis.pogamut.ut2004.bot.sposh.UT2004Behaviour;
import cz.cuni.amis.pogamut.ut2004.communication.messages.ItemType.Category;
import cz.cuni.amis.pogamut.ut2004.communication.messages.UnrealId;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.BotKilled;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.ConfigChange;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.GameInfo;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.InitedMessage;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.Item;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.Player;
import cz.cuni.amis.pogamut.ut2004.communication.messages.gbinfomessages.Self;

/**
 * Simplest derivation of behaviour from original one.
 *
 * Implement senses and action from your SPOSH plan as described in the description of
 * {@link UT2004Behaviour} class.
 */
public class BotBehaviour extends UT2004Behaviour<UT2004Bot> {

    public BotBehaviour(String name, UT2004Bot bot) {
        super(name, bot);
    }

    /**
     * Called during the behaviour construction (by UT2004Behaviour) to initialize 
     * custom data structures / modules.
     */
    @Override
    protected void prepareBehaviour(UT2004Bot bot) {
        // TODO bot's state / custom data structures initialization
    }

    @Override
    public void botInitialized(GameInfo info, ConfigChange config, InitedMessage init) {
        // TODO called after the bot was initialized
    }

    // The parent of this class - UT2004Behaviour contains many modules that can help 
    //                            you with querying bot's world view and issuing commands	
    //
    // this.game         // Memory module specialized on general info about the game:
    //     game type, time limit, frag limit, etc.
    // this.info         // Memory module specialized on general info about the agent whereabouts:
    //     location, rotation, health, current weapon, who is enemy/friend, etc.
    // this.players      // Memory module specialized on whereabouts of other players:
    //     who is visible, enemy / friend, whether bot can see anybody, etc.
    // this.descriptors  // Sensory module that provides mapping between ItemType and ItemDescriptor 
    // providing an easy way to obtain item descriptors for various items in UT2004.
    // this.items        // Memory module specialized on items on the map - which are visible and which are probably spawned.
    // this.senses       // Memory module specialized on agent's senses:
    //     whether the bot has been recently killed, collide with level's geometry, etc.
    // this.weaponry     // Memory module specialized on info about the bot's weapon and ammo inventory.
    //     It can tell you which weapons are loaded, melee/ranged, etc.
    // this.config       // Memory module specialized on the agent's configuration inside UT2004:
    //     name, vision time, manual spawn, cheats (if enabled at GB2004).
    // this.raycasting   // Support for creating rays used for raycasting (see {@link AutoTraceRay} that is being utilized).
    // this.body         // Wraps all available commands that can be issued to the virtual body of the bot inside UT2004.
    // this.shoot        // Shortcut for <i>body.getAdvancedShooting()</i> that allows you to shoot at opponent.
    // this.move         // Shortcut for <i>body.getAdvancedLocomotion()</i> that allows you to manually 
    //     steer the movement through the environment.
    // this.pathPlanner  // Planner used to compute the path (consisting of navigation points) inside the map.
    // this.pathExecutor // Executor is used for following a path in the environment.
    //     note that you need to attach listeners to path events and add stuck detector if you want to use pathExecutor
    //     see NavigationBot sample for example implementation of the listener
    @Override
    public void botSpawned(GameInfo gameInfo, ConfigChange config, InitedMessage init, Self self) {
        // TODO bot is spawned for the first time in the environment
        // examine 'self' to examine current bot's location and other stuff, initialize things 
        // dependent on that
    }

    @Override
    public void botKilled(BotKilled event) {
        // TODO clear bot's state / custom data structures
    }

    @SPOSHSense
    public boolean emptySense() {
        return true;
    }

    @SPOSHAction
    public boolean emptyAction() {
        return true;
    }

    @SPOSHAction
    public boolean turn() {
        move.turnHorizontal(30);
        return true;
    }

    @cz.cuni.amis.pogamut.sposh.SPOSHSense
    public int health() {
        return info.getHealth();
    }

    @cz.cuni.amis.pogamut.sposh.SPOSHAction
    public boolean jump() {
        move.jump();
        return true;
    }

    @cz.cuni.amis.pogamut.sposh.SPOSHSense
    public double playerDistance() {
        Player nearest = DistanceUtils.getNearest(players.getPlayers().values(), info.getLocation());
        if (nearest == null) {
            return Double.MAX_VALUE;
        }
        return Location.getDistance(nearest.getLocation(), info.getLocation());
    }

    @cz.cuni.amis.pogamut.sposh.SPOSHSense
    public boolean hitWall() {
        return senses.isCollidingOnce();
    }

    @cz.cuni.amis.pogamut.sposh.SPOSHAction
    public boolean runHealths() {
        if (pathExecutor.isMoving())
            return true;
        // find the closest healthpack
        Item nearest = DistanceUtils.getNearest(
                items.getSpawnedItems(Category.HEALTH).values(),
                bot);
        // We dont think there are spawned healths in the level, but the action
        // itself hasnt failed
        if (nearest == null) {
            return true;
        }
        pathExecutor.followPath(pathPlanner.computePath(nearest));
        return  true;
    }
}
